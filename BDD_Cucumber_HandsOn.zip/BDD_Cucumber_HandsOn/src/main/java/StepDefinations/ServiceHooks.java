package StepDefinations;

import com.cucumberFramework.BasePage;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class ServiceHooks extends BasePage {
    @Before
    public void initializeBrowser(){
       openBrowser();
    }
    @After
    public void closeBrowser(){
        driver.quit();
    }
}
