package StepDefinations;

import com.cucumberFramework.BasePage;
import com.cucumberFramework.Pages.AfaLoginPage;
import com.cucumberFramework.Pages.CheckoutPage;
import com.cucumberFramework.Pages.HomePage;
import com.cucumberFramework.Pages.ProductPage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefination extends BasePage {

    protected static final String PROCEED_TO_CHECKOUT_BUTTON_XPATH = "//input[@data-action='proceedToCheckout' and @data-attribute='checkout']";
    String PLACE_ORDER_XPATH = "//input[@class='btn btn-primary pull-right js-modal-place-order'][1]";
    AfaLoginPage LoginPage = new AfaLoginPage();
    HomePage HomePage = new HomePage();
    ProductPage ProductPage = new ProductPage();
CheckoutPage CheckoutPage = new CheckoutPage();


    @Given("I'm on login Page")
    public void load_Login_Page() throws InterruptedException {
        LoginPage.logintoAfa();
    }


    @And("I've added product to cart {string}")
    public void add_Product_To_Cart(String arg0) {
        ProductPage.setProductQuantity(arg0);
        ProductPage.selectHomeDelivery();
    }

    @Then("Search customer")
    public void search_Customer(){
       HomePage.search_Customer("0083755854");
    }

    @Given("I'm logged in to Contact Centre")
    public void loginToAfa() throws InterruptedException {

        LoginPage.logintoAfa();
        LoginPage.selectStore("1162");
        }

        @When("Search Product")
    public void search_Product() throws InterruptedException {
         HomePage.search_Product("9992601427306");
    }

    @And("Place Order")
    public void placeOrder() {
CheckoutPage.placeOrder();
    }

    @Then("Search Product {string}")
    public void searchProduct(String arg0) throws InterruptedException {
        HomePage.search_Product(arg0);
    }

    @Then("Proceed To Checkout")
    public void proceedToCheckout() {
CheckoutPage.proceedToCheckout();
    }

    @And("login with credentials {string}")
    public void loginWithCredentials(String arg0) {
        LoginPage.selectStore(arg0);
    }

    @Then("Search customer {string}")
    public void searchCustomer(String arg0) {
        HomePage.search_Customer(arg0);
    }


    @Then("Get Order Details")
    public void getOrderDetails() {
        CheckoutPage.getOrderDetails();
    }


    @Then("Click on Finish with Customer")
    public void clickOnFinishWithCustomer() {
        CheckoutPage.finishWithCustomer();
    }

    @Then("Search the order")
    public void searchTheOrder() {
        HomePage.search_Order();

    }
}


