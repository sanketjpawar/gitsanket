package com.cucumberFramework;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v120.storage.Storage;

public class BasePage {
    public  static WebDriver driver;
//    protected final Storage storage = Storage.getInstance();

    public WebDriver openBrowser() {
                System.setProperty("webdriver.chrome.driver", "C:\\Users\\PAWARS04\\OneDrive - Kingfisher PLC\\Desktop\\Sanket Pawar\\chromedriver_win32\\chromedriver.exe");
                driver = new ChromeDriver();
                driver.manage().window().maximize();
        return driver;
    }
}
