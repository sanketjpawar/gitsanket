package com.cucumberFramework.enums;

import com.cucumberFramework.BasePage;
import org.openqa.selenium.devtools.v120.storage.Storage;

import java.util.HashMap;
import java.util.Map;

public class ScenarioContext extends BasePage {
    private Map<String, Object> scenarioContext;

    public ScenarioContext(){
        scenarioContext = new HashMap<String, Object>();
    }

    public void setContext(Context key, Object value) {
        scenarioContext.put(key.toString(), value);
    }

    public Object getValue(Context key){
        return scenarioContext.get(key.toString());
    }

    public Boolean isContains(Context key){
        return scenarioContext.containsKey(key.toString());
    }
}

