package com.cucumberFramework.enums;

public enum Context {
    sapOrderId,
    userName,
    password;

}
