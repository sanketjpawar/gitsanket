package com.cucumberFramework.Helper;
import com.cucumberFramework.BasePage;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class WaitHelper extends BasePage {
//    Logger logger = LoggerHelper.getLogger(WaitHelper.class);
//
//    private static WebDriver driver;
//
//    public WaitHelper(WebDriver driver){
//        this.driver = driver;
//    }

	public static void waitForPageToLoad(WebElement element){
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public static void waitForTime(int seconds){
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
	}

}
