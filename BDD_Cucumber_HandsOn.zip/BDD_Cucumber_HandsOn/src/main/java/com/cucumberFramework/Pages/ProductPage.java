package com.cucumberFramework.Pages;

import com.cucumberFramework.BasePage;
import com.cucumberFramework.Helper.WaitHelper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ProductPage extends BasePage {

    String PROCEED_TO_BASKET = "//input[@id='proceed-basket']";

    String ACTIONS_BUTTON = ("//*[@id='findview-action-select']");
    //    @FindBy(xpath= "//input[@id='proceed-basket']") public WebElement PROCEED_TO_BASKET;
    @FindBy(xpath = ".//a[@class='js-modal js-modal-scroll js-store-locator']")
    public WebElement SELECT_STORE;
    @FindBy(xpath = ".//input[@id='find-store']")
    public WebElement ENTER_STORE_ID;
    @FindBy(xpath = ".//input[@class='btn btn-search store-locator-submit']")
    public WebElement FIND_STORE;
    @FindBy(xpath = ".//input[@name='selectCCStore']")
    public WebElement SELECT_CCSTORE;

    public void setProductQuantity(String quantity) {

//        QUANTITY_FIELD_XPATH.click();
//        QUANTITY_FIELD_XPATH.clear();
//        QUANTITY_FIELD_XPATH.sendKeys(quantity);
//        driver.findElement(By.xpath(QUANTITY_FIELD_XPATH)).click();
////        WaitHelper.WaitForPageToLoad();
        WebElement Quantity_Field = driver.findElement(By.name("item-quantity"));
        Actions action = new Actions(driver);
//        action.moveToElement(Quantity_Field).doubleClick().sendKeys("2");
        action.doubleClick(Quantity_Field).sendKeys("2").build().perform();


//        driver.findElement(By.name("item-quantity")).isDisplayed();
//        driver.findElement(By.name("item-quantity")).click();
//        driver.findElement(By.name("item-quantity")).do
//        driver.findElement(By.name("item-quantity")).sendKeys("2");
    }

    public void selectHomeDelivery() {
        Select actions = new Select(driver.findElement(By.xpath(ACTIONS_BUTTON)));
        actions.selectByValue("purchase-hd");
        driver.findElement(By.xpath(PROCEED_TO_BASKET)).click();
    }

    public void selectClickAndCollect() {
        Select actions = new Select(driver.findElement(By.xpath(ACTIONS_BUTTON)));
        actions.selectByValue("purchase-sd");
        driver.findElement(By.xpath(PROCEED_TO_BASKET)).click();
    }

    public void selectStore(String storeId) {

        SELECT_STORE.isDisplayed();
        SELECT_STORE.click();
        ENTER_STORE_ID.isDisplayed();
        ENTER_STORE_ID.sendKeys(storeId);
        FIND_STORE.click();
        SELECT_CCSTORE.isDisplayed();
        SELECT_CCSTORE.click();
    }

}

