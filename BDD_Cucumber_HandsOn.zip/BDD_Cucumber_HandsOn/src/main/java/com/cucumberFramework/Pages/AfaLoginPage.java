package com.cucumberFramework.Pages;

import com.cucumberFramework.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class AfaLoginPage extends BasePage {
    //    private WebDriver driver;
    private static final String LOGIN_FIELD_XPATH = ".//input[@id='user']";
    private static final String PASSWORD_FIELD_XPATH = ".//input[@id='pwd']";
    private static final String SIGN_IN_BUTTON_XPATH = ".//input[@type='submit']";
    private static final String SIGN_BACK_IN_BUTTON = ".//input[@value='Sign Back In']";
    private static final String LOCATION_FIELD_XPATH = ".//input[@id='location']";
    private static final String CONFIRM_LOCATION_BUTTON_XPATH = ".//input[@id='confirmLocation']";
    private static final String CONTINUE_BUTTON_XPATH = ".//input[@class='btn btn-primary location-continue']";
    @FindBy(xpath = "//input[@id='user']")
    public WebElement USERNAME_FIELD;
    @FindBy(xpath = "//input[@id='pwd']")
    public WebElement PASSWORD_FIELD;
    @FindBy(xpath = "//input[@type='submit']")
    public WebElement SIGN_IN_BUTTON;
    @FindBy(xpath = "//input[@id='location']")
    public WebElement LOCATION_FIELD;
    @FindBy(xpath = "//input[@id='confirmLocation']")
    public WebElement CONFIRM_LOCATION;
    @FindBy(xpath = "//input[@class='btn btn-primary location-continue']")
    public WebElement CONTINUE;
    String AFA_URL = "http://atg-tcbquk01-aws-app01.aws.ghanp.kfplc.com:8030/agent-front/jsp/agent/login.jsp";


//    public AfaLoginPage(WebDriver driver){
//        this.driver = driver;
//        PageFactory.initElements(driver, this);
//    }

    public void logintoAfa() throws InterruptedException {
//        openBrowser();
        driver.get(AFA_URL);
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).isDisplayed();
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).sendKeys("service");
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).isDisplayed();
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).sendKeys("Service123");
        driver.findElement(By.xpath(SIGN_IN_BUTTON_XPATH)).click();
    }

    public void selectStore(String storeId) {
//        driver.LOCATION_FIELD.clear();
        driver.findElement(By.xpath(LOCATION_FIELD_XPATH)).clear();
        driver.findElement(By.xpath(LOCATION_FIELD_XPATH)).sendKeys(storeId);
        driver.findElement(By.xpath(CONFIRM_LOCATION_BUTTON_XPATH)).click();
        driver.findElement(By.xpath(CONTINUE_BUTTON_XPATH)).click();
    }
}
