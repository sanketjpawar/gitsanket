package com.cucumberFramework.Pages;

import com.cucumberFramework.BasePage;
import com.cucumberFramework.Helper.WaitHelper;
import com.cucumberFramework.enums.ScenarioContext;
import org.openqa.selenium.By;

import java.util.concurrent.TimeUnit;

import static com.cucumberFramework.enums.Context.sapOrderId;


public class HomePage extends BasePage {

protected static final String CUSTOMER_ID_INPUT = "details";
    protected static final String LOOK_UP_CUSTOMER_BUTTON_XPATH = ".//input[@data-title='Customer']";
    protected static final String PRODUCTS_LINK = "//a[@class='js-search-product']";
    protected static final String PRODUCT_SEARCH_BUTTON = ".//input[@id='findview-search-submit']";
    protected static final String PRODUCT_SEARCH = ".//input[@id='quickbuy-search-product']";
    private static final String SEARCH_ORDER_FIELD_XPATH = ".//input[@id='order']";
    private static final String LOOK_UP_ORDERS_BUTTON_XPATH = ".//input[@data-title='Orders']";
    ScenarioContext scenarioContext;


    public void search_Product(String ean) throws InterruptedException {
        WaitHelper.waitForPageToLoad(driver.findElement(By.xpath(PRODUCTS_LINK)));
        driver.findElement(By.xpath(PRODUCTS_LINK)).isDisplayed();
        driver.findElement(By.xpath(PRODUCTS_LINK)).click();
//        WaitHelper.waitForPageToLoad(findElement(By.xpath(PRODUCT_SEARCH_BUTTON)));
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath(PRODUCT_SEARCH)).click();
        driver.findElement(By.xpath(PRODUCT_SEARCH)).sendKeys(ean);
        driver.findElement(By.xpath(PRODUCT_SEARCH_BUTTON)).click();
    }

    public void search_Customer(String customerId){
        driver.findElement(By.id(CUSTOMER_ID_INPUT)).click();
        driver.findElement(By.id(CUSTOMER_ID_INPUT)).sendKeys(customerId);
        driver.findElement(By.xpath(LOOK_UP_CUSTOMER_BUTTON_XPATH)).click();
    }
    public void search_Order(){
//        String orderId=scenarioContext.getValue(sapOrderId).toString();
        driver.findElement(By.id("order")).click();
//        driver.findElement(By.id("order")).sendKeys(storage.whatIsThe("sapOrderId"));
        driver.findElement(By.xpath(LOOK_UP_ORDERS_BUTTON_XPATH)).click();
    }
}

