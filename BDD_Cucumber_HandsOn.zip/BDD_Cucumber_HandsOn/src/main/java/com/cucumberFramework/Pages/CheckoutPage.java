package com.cucumberFramework.Pages;

import com.cucumberFramework.BasePage;
import com.cucumberFramework.enums.ScenarioContext;
import org.openqa.selenium.By;
import org.openqa.selenium.devtools.v120.storage.Storage;

import java.util.concurrent.TimeUnit;

import static com.cucumberFramework.enums.Context.sapOrderId;

public class CheckoutPage extends BasePage {
    protected static final String PROCEED_TO_CHECKOUT_BUTTON_XPATH = "//input[@data-action='proceedToCheckout' and @data-attribute='checkout']";
    protected static final String PLACE_ORDER_XPATH = "//input[@class='btn btn-primary pull-right js-modal-place-order'][1]";
    protected static final String SELECT_STORE_LINK_XPATH = ".//a[@class='js-modal js-modal-scroll js-store-locator']";
    protected static final String POSTCODE_TEXTFIELD_XPATH = ".//input[@id='find-store']";
    protected static final String FIND_STORE_XPATH = ".//input[@class='btn btn-search store-locator-submit']";
    protected static final String SELECT_STORE_BUTTON_XPATH = ".//input[@name='selectCCStore']";
    protected static final String ORDER_ID_XPATH = ".//dd[@id='sapOrderId']";
    protected static final String TOTAL_PAYMENT = "(//dl[@class='definition-desc-inline summary']/dd)[2]";
    protected static final String FINISH_WITH_CUSTOMER_BUTTON_XPATH = ".//input[@class='btn btn-primary quote-btn' or @class='btn pull-right btn-primary']";
    ScenarioContext scenarioContext;

    public void proceedToCheckout() {
        driver.findElement(By.xpath(PROCEED_TO_CHECKOUT_BUTTON_XPATH)).isEnabled();
        driver.findElement(By.xpath(PROCEED_TO_CHECKOUT_BUTTON_XPATH)).click();
    }

    public void placeOrder() {
        driver.findElement(By.xpath(PLACE_ORDER_XPATH)).isDisplayed();
        driver.findElement(By.xpath(PLACE_ORDER_XPATH)).click();
    }

    public void selectCCStore(String storeId){
        driver.findElement(By.xpath(SELECT_STORE_LINK_XPATH)).isDisplayed();
        driver.findElement(By.xpath(SELECT_STORE_LINK_XPATH)).click();
        driver.findElement(By.xpath(POSTCODE_TEXTFIELD_XPATH)).isDisplayed();
        driver.findElement(By.xpath(POSTCODE_TEXTFIELD_XPATH)).sendKeys(storeId);
        driver.findElement(By.xpath(FIND_STORE_XPATH)).click();
        driver.findElement(By.xpath(SELECT_STORE_BUTTON_XPATH)).isDisplayed();
        driver.findElement(By.xpath(SELECT_STORE_BUTTON_XPATH)).click();
    }

    public void getOrderDetails() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        String orderId = driver.findElement(By.xpath(ORDER_ID_XPATH)).getText();
        String TotalPayment = driver.findElement(By.xpath(TOTAL_PAYMENT)).getText();
        System.out.println("Order Id : "+ orderId);
        System.out.println("Order Amount : "+ TotalPayment);
//        storage.rememberThatThe("sapOrderId", orderId);
//        Logger log = LoggerHelper.getLogger(LoggerHelper.class);
//        scenarioContext.setContext(sapOrderId,orderId);
//        driver.close();
    }
    public void finishWithCustomer() {
        driver.findElement(By.xpath(FINISH_WITH_CUSTOMER_BUTTON_XPATH)).isDisplayed();
        driver.findElement(By.xpath(FINISH_WITH_CUSTOMER_BUTTON_XPATH)).click();
    }
}
